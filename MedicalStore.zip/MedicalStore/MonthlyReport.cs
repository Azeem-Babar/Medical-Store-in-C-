﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MedicalStore
{
    public partial class MonthlyReport : Form
    {
   string connectionString = ConfigurationManager.ConnectionStrings["connection_string"].ConnectionString;
      DataTable monthobj =  new DataTable();
        public MonthlyReport()
        {
            InitializeComponent();
        }
        

        private void MonthlyReport_Load(object sender, EventArgs e)
        {
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
          

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainForm mainFormobj = new MainForm();
            this.Hide();
            mainFormobj.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainForm mainFormobj = new MainForm();
            this.Hide();
            mainFormobj.ShowDialog();
        }

        private void MonthlyReport_Load_1(object sender, EventArgs e)
        {
           // loadMedicineMonthlyData();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        //private void loadMedicineMonthlyData()
        //{

        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        using (SqlCommand cmd = new SqlCommand("spSaleRecords", con))
        //        {
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            con.Open();
        //            using (var da = new SqlDataAdapter(cmd))
        //            {
        //                da.Fill(monthobj);
        //            }
        //            con.Close();
        //            dataGridView2.DataSource = monthobj;
        //        }
        //    }
        //}

        private void button4_Click(object sender, EventArgs e)
        {
            MonthlyRecordsDate(dateTimePicker1.Value.Date, dateTimePicker2.Value.Date);
        }

        private void MonthlyRecordsDate(DateTime date1, DateTime date2)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("select * from saleRecords where sdate between  '"+date1.ToString("yyyy-MM-dd") + "' AND '" + date2.ToString("yyyy-MM-dd") + "'", con))
                {
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    using (var da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(monthobj);
                    }
                    con.Close();
                    dataGridView2.DataSource = monthobj;
                }
            }

        }
    }
}
