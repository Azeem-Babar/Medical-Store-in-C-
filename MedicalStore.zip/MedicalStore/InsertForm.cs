﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicalStore
{
    public partial class InsertForm : Form
    {
        int updatedRowsCount;
        public InsertForm()
        {
            InitializeComponent();
        }

        private void InsertForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            insermedicine(textBox1.Text, textBox2.Text, int.Parse(textBox3.Text), textBox4.Text, dateTimePicker1.Value.Date);
            if (updatedRowsCount > 0)
            {
                MessageBox.Show("Medicine Inserted Successfully");
            }
        }
        private int insermedicine(string name, string price,int quantity, string manufacture , DateTime date)
        {
            String ConnectionString = "Data Source=AZEEM-BABAR;Initial Catalog=MadicalStore;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            conn.ConnectionString = ConnectionString;
            conn.Open();

            comm.CommandText = "insert into insertmedicine (name, price ,quantity,manufacture, date)VALUES('" + name + "', '" + price + "', '" + quantity + "', '" + manufacture + "','"+date+"')";
            comm.Connection = conn;
            updatedRowsCount = comm.ExecuteNonQuery();
            conn.Close();
            return updatedRowsCount;

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainForm mainFormobj = new MainForm();
            this.Hide();
            mainFormobj.ShowDialog();
        }
    }
}

