﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicalStore
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertForm insertobj = new InsertForm();
            insertobj.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PurchaseMedicine purchaseobj = new PurchaseMedicine();
            this.Hide();
            purchaseobj.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaleMedicine saleobj = new SaleMedicine();
            this.Hide();
            saleobj.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MonthlyReport monthlyobj = new MonthlyReport();
            this.Hide();
            monthlyobj.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
