﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration; 

namespace MedicalStore
{
    public partial class PurchaseMedicine : Form
    {
        int updatedRowsCount;
       // string name = textBox6.Text;
        string connectionString = ConfigurationManager.ConnectionStrings["connection_string"].ConnectionString;
        DataTable allMedicineData = new DataTable();
        public PurchaseMedicine()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void loadMedicineData()
        {

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("spAllMedicine", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    using (var da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(allMedicineData);
                    }
                    con.Close();
                    dataGridView1.DataSource = allMedicineData;
                }
            }
        }

        private void PurchaseMedicine_Load(object sender, EventArgs e)
        {
            loadMedicineData();
        }
        private void populateSearchedCust()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("spSearchMedicineInPurchase", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@name", textBox1.Text);
                    con.Open();
                    using (var da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                    con.Close();
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            insermedicineSale(textBox6.Text, textBox7.Text, int.Parse(textBox8.Text), textBox9.Text, dateTimePicker2.Value.Date);
            if (updatedRowsCount > 0)
            {
                MessageBox.Show("Medicine Sold Successfully");
            }
            deleteRowFromInsertTable(textBox6.Text);
        }

        private int deleteRowFromInsertTable( string namemed)
        {
           
                String ConnectionString = "Data Source=AZEEM-BABAR;Initial Catalog=MadicalStore;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                SqlCommand comm = new SqlCommand();
                SqlDataAdapter da = new SqlDataAdapter();
                DataTable dt = new DataTable();

                conn.ConnectionString = ConnectionString;
                conn.Open();

                comm.CommandText = "delete from insertmedicine where name = '"+namemed+"'";
                comm.Connection = conn;
                updatedRowsCount = comm.ExecuteNonQuery();
                conn.Close();
                return updatedRowsCount;

            }
        

        private int insermedicineSale(string name, string price, int quantity, string manufacture, DateTime date)
        {
            String ConnectionString = "Data Source=AZEEM-BABAR;Initial Catalog=MadicalStore;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            conn.ConnectionString = ConnectionString;
            conn.Open();

            comm.CommandText = "insert into saleRecords (sname, sprice ,squantity,smanufacture, sdate)VALUES('" + name + "', '" + price + "', '" + quantity + "', '" + manufacture + "','" + date + "')";
            comm.Connection = conn;
            updatedRowsCount = comm.ExecuteNonQuery();
            conn.Close();
            return updatedRowsCount;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainForm mainFormobj = new MainForm();
            this.Hide();
            mainFormobj.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            populateSearchedCust();
        }
    }
    }

