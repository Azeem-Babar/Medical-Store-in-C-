﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicalStore
{
    public partial class SaleMedicine : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["connection_string"].ConnectionString;
        DataTable allMedicineSale = new DataTable();
        public SaleMedicine()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void loadMedicineSaleData()
        {

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("spSaleRecords", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    using (var da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(allMedicineSale);
                    }
                    con.Close();
                    dataGridView1.DataSource = allMedicineSale;
                }
            }
        }

        private void SaleMedicine_Load(object sender, EventArgs e)
        {
            loadMedicineSaleData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainForm mainFormobj = new MainForm();
            this.Hide();
            mainFormobj.ShowDialog();
        }
    }
}
